# سوق ليبيا

تطبيق بيع وشراء ليبي (Flutter + Supabase).

## المزايا
- تسجيل حساب ودخول (بريد + كلمة مرور) واستعادة كلمة المرور
- نشر إعلان بصور (حتى 8)، سعر بالدينار، تصنيف، مدينة، جديد/مستعمل
- بحث وفلاتر (تصنيف، مدينة) وتحميل تدريجي
- المفضلة، إعلاناتي، تحديد كمباع، حذف
- اتصال وواتساب مباشر مع البائع
- الإبلاغ عن الإعلانات، وصلاحيات مشرف لحذف المخالف

## تحميل APK
تبويب **Actions** ثم آخر تشغيل ثم Artifacts، أو من **Releases** مباشرة من الهاتف.

## ترقية مستخدم إلى مشرف
نفّذ في SQL Editor بلوحة Supabase:
```sql
update public.profiles set is_admin = true
where id = (select id from auth.users where email = 'بريدك@example.com');
```

## الإعدادات
القيم في `lib/config.dart` (رابط المشروع والمفتاح العام). يمكن تغييرها عند البناء:
`flutter build apk --dart-define=SUPABASE_URL=... --dart-define=SUPABASE_KEY=...`

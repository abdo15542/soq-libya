class Config {
  // المفتاح العام (publishable) مصمم ليكون داخل التطبيق، وحمايته تتم عبر RLS في قاعدة البيانات.
  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://ywcjvooqneskbajvtnwt.supabase.co',
  );
  static const supabaseKey = String.fromEnvironment(
    'SUPABASE_KEY',
    defaultValue: 'sb_publishable_hLrMVTTiLgfCpo_5V07MgA_GU0aucNu',
  );
}

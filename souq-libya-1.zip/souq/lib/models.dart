class Category {
  final int id;
  final String slug;
  final String name;
  Category(this.id, this.slug, this.name);
  factory Category.fromMap(Map<String, dynamic> m) =>
      Category(m['id'] as int, m['slug'] as String, m['name_ar'] as String);
}

class City {
  final int id;
  final String name;
  City(this.id, this.name);
  factory City.fromMap(Map<String, dynamic> m) =>
      City(m['id'] as int, m['name_ar'] as String);
}

class Listing {
  final String id;
  final String userId;
  final String title;
  final String description;
  final double? price;
  final int categoryId;
  final int cityId;
  final String condition;
  final List<String> images;
  final String sellerName;
  final String contactPhone;
  final String status;
  final DateTime createdAt;

  Listing({
    required this.id,
    required this.userId,
    required this.title,
    required this.description,
    required this.price,
    required this.categoryId,
    required this.cityId,
    required this.condition,
    required this.images,
    required this.sellerName,
    required this.contactPhone,
    required this.status,
    required this.createdAt,
  });

  factory Listing.fromMap(Map<String, dynamic> m) => Listing(
        id: m['id'] as String,
        userId: m['user_id'] as String,
        title: m['title'] as String,
        description: (m['description'] ?? '') as String,
        price: m['price'] == null ? null : (m['price'] as num).toDouble(),
        categoryId: m['category_id'] as int,
        cityId: m['city_id'] as int,
        condition: (m['condition'] ?? 'used') as String,
        images: List<String>.from(m['images'] ?? const []),
        sellerName: (m['seller_name'] ?? '') as String,
        contactPhone: (m['contact_phone'] ?? '') as String,
        status: (m['status'] ?? 'active') as String,
        createdAt: DateTime.parse(m['created_at'] as String).toLocal(),
      );
}

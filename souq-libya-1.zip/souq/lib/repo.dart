import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'models.dart';

SupabaseClient get sb => Supabase.instance.client;

class Pic {
  final Uint8List bytes;
  final String ext;
  Pic(this.bytes, this.ext);
}

class Repo {
  static const bucket = 'listing-images';
  static List<Category> categories = [];
  static List<City> cities = [];
  static bool? _isAdmin;

  static Future<void> loadLookups() async {
    final c = await sb.from('ad_categories').select().order('sort_order');
    categories = (c as List).map((e) => Category.fromMap(e)).toList();
    final ci = await sb.from('cities').select().order('id');
    cities = (ci as List).map((e) => City.fromMap(e)).toList();
  }

  static String categoryName(int id) =>
      categories.where((c) => c.id == id).map((c) => c.name).firstOrNull ?? '';
  static String cityName(int id) =>
      cities.where((c) => c.id == id).map((c) => c.name).firstOrNull ?? '';

  static String? get uid => sb.auth.currentUser?.id;

  static Future<List<Listing>> fetch({
    String? q,
    int? categoryId,
    int? cityId,
    int limit = 20,
    int offset = 0,
  }) async {
    var query = sb.from('listings').select().eq('status', 'active');
    if (categoryId != null) query = query.eq('category_id', categoryId);
    if (cityId != null) query = query.eq('city_id', cityId);
    if (q != null && q.trim().isNotEmpty) {
      final s = q.trim().replaceAll(RegExp(r'[%,()*]'), ' ');
      query = query.or('title.ilike.%$s%,description.ilike.%$s%');
    }
    final data = await query
        .order('created_at', ascending: false)
        .range(offset, offset + limit - 1);
    return (data as List).map((e) => Listing.fromMap(e)).toList();
  }

  static Future<List<Listing>> myListings() async {
    final data = await sb
        .from('listings')
        .select()
        .eq('user_id', uid!)
        .order('created_at', ascending: false);
    return (data as List).map((e) => Listing.fromMap(e)).toList();
  }

  static Future<List<Listing>> favorites() async {
    final data = await sb
        .from('favorites')
        .select('listings(*)')
        .eq('user_id', uid!)
        .order('created_at', ascending: false);
    return (data as List)
        .map((e) => e['listings'])
        .where((e) => e != null)
        .map((e) => Listing.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  static Future<bool> isFavorite(String listingId) async {
    if (uid == null) return false;
    final r = await sb
        .from('favorites')
        .select('listing_id')
        .eq('user_id', uid!)
        .eq('listing_id', listingId)
        .maybeSingle();
    return r != null;
  }

  static Future<void> setFavorite(String listingId, bool on) async {
    if (on) {
      await sb.from('favorites').insert({'user_id': uid, 'listing_id': listingId});
    } else {
      await sb
          .from('favorites')
          .delete()
          .eq('user_id', uid!)
          .eq('listing_id', listingId);
    }
  }

  static Future<Map<String, dynamic>?> profile() async {
    if (uid == null) return null;
    final r = await sb.from('profiles').select().eq('id', uid!).maybeSingle();
    _isAdmin = r?['is_admin'] == true;
    return r;
  }

  static Future<bool> isAdmin() async {
    if (uid == null) return false;
    if (_isAdmin == null) await profile();
    return _isAdmin ?? false;
  }

  static void clearCache() => _isAdmin = null;

  static Future<List<String>> uploadImages(List<Pic> pics) async {
    final urls = <String>[];
    final stamp = DateTime.now().microsecondsSinceEpoch;
    for (var i = 0; i < pics.length; i++) {
      final p = pics[i];
      final path = '$uid/${stamp}_$i.${p.ext}';
      final ct = p.ext == 'png'
          ? 'image/png'
          : p.ext == 'webp'
              ? 'image/webp'
              : 'image/jpeg';
      await sb.storage
          .from(bucket)
          .uploadBinary(path, p.bytes, fileOptions: FileOptions(contentType: ct));
      urls.add(sb.storage.from(bucket).getPublicUrl(path));
    }
    return urls;
  }

  static Future<void> createListing(Map<String, dynamic> data) async {
    await sb.from('listings').insert(data);
  }

  static Future<void> setStatus(String id, String status) async {
    await sb.from('listings').update({'status': status}).eq('id', id);
  }

  static Future<void> deleteListing(Listing l) async {
    await sb.from('listings').delete().eq('id', l.id);
    try {
      final marker = '/$bucket/';
      final paths = l.images
          .where((u) => u.contains(marker))
          .map((u) => Uri.decodeComponent(u.split(marker).last))
          .toList();
      if (paths.isNotEmpty) await sb.storage.from(bucket).remove(paths);
    } catch (_) {}
  }

  static Future<void> report(String listingId, String reason) async {
    await sb
        .from('reports')
        .insert({'listing_id': listingId, 'reporter_id': uid, 'reason': reason});
  }
}

String arabicError(Object e) {
  final m = e is AuthException
      ? e.message
      : e is PostgrestException
          ? e.message
          : e.toString();
  if (m.contains('Invalid login credentials')) {
    return 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
  }
  if (m.contains('already registered')) return 'هذا البريد مسجّل مسبقاً';
  if (m.contains('Email not confirmed')) {
    return 'لم يتم تأكيد البريد بعد، افتح الرسالة المرسلة إلى بريدك';
  }
  if (m.contains('Password should be')) {
    return 'كلمة المرور ضعيفة (6 أحرف على الأقل)';
  }
  if (m.contains('row-level security')) {
    return 'غير مسموح لك بتنفيذ هذا الإجراء (قد يكون حسابك محظوراً)';
  }
  if (m.contains('duplicate key')) return 'تم تنفيذ هذا الإجراء من قبل';
  if (m.contains('SocketException') || m.contains('Failed host lookup')) {
    return 'لا يوجد اتصال بالإنترنت';
  }
  return 'حدث خطأ: $m';
}

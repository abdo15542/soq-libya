import 'package:flutter/material.dart';
import '../models.dart';
import '../repo.dart';
import '../utils.dart';
import 'auth_screen.dart';
import 'widgets.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: AuthGuard(
        loggedOut: (_) => const AuthScreen(embedded: true),
        builder: (_) => const _AccountBody(),
      ),
    );
  }
}

class _AccountBody extends StatefulWidget {
  const _AccountBody();
  @override
  State<_AccountBody> createState() => _AccountBodyState();
}

class _AccountBodyState extends State<_AccountBody> {
  late Future<List<Listing>> _f = Repo.myListings();
  late Future<Map<String, dynamic>?> _p = Repo.profile();

  void _reload() => setState(() => _f = Repo.myListings());

  Future<void> _delete(Listing l) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف الإعلان'),
        content: const Text('هل أنت متأكد؟ لا يمكن التراجع.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('حذف')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Repo.deleteListing(l);
      _reload();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(arabicError(e))));
      }
    }
  }

  Future<void> _toggleSold(Listing l) async {
    try {
      await Repo.setStatus(l.id, l.status == 'sold' ? 'active' : 'sold');
      _reload();
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(arabicError(e))));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final user = sb.auth.currentUser!;
    return RefreshIndicator(
      onRefresh: () async => _reload(),
      child: ListView(
        padding: const EdgeInsets.only(bottom: 90),
        children: [
          FutureBuilder<Map<String, dynamic>?>(
            future: _p,
            builder: (context, snap) {
              final name = (snap.data?['full_name'] ?? '') as String;
              final admin = snap.data?['is_admin'] == true;
              return ListTile(
                leading: const CircleAvatar(child: Icon(Icons.person)),
                title: Text(name.isEmpty ? 'مستخدم' : name),
                subtitle: Text(user.email ?? ''),
                trailing: admin
                    ? const Chip(label: Text('مشرف'))
                    : null,
              );
            },
          ),
          const Divider(),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Text('إعلاناتي',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          FutureBuilder<List<Listing>>(
            future: _f,
            builder: (context, snap) {
              if (snap.connectionState != ConnectionState.done) {
                return const Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(child: CircularProgressIndicator()));
              }
              if (snap.hasError) {
                return Padding(
                    padding: const EdgeInsets.all(16),
                    child: Text(arabicError(snap.error!)));
              }
              final items = snap.data!;
              if (items.isEmpty) {
                return const Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(child: Text('لم تنشر أي إعلان بعد')));
              }
              return Column(
                children: [
                  for (final l in items)
                    Card(
                      margin: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 4),
                      child: ListTile(
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(6),
                          child: SizedBox(
                            width: 56,
                            height: 56,
                            child: l.images.isEmpty
                                ? Container(
                                    color: Colors.grey.shade200,
                                    child: const Icon(Icons.image_outlined))
                                : Image.network(l.images.first,
                                    fit: BoxFit.cover,
                                    errorBuilder: (_, __, ___) =>
                                        const Icon(Icons.broken_image)),
                          ),
                        ),
                        title: Text(l.title,
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text(
                            '${formatPrice(l.price)}${l.status == 'sold' ? ' · تم البيع' : ''}${l.status == 'hidden' ? ' · مخفي' : ''}'),
                        trailing: PopupMenuButton<String>(
                          onSelected: (v) =>
                              v == 'sold' ? _toggleSold(l) : _delete(l),
                          itemBuilder: (_) => [
                            PopupMenuItem(
                                value: 'sold',
                                child: Text(l.status == 'sold'
                                    ? 'إعادة نشر'
                                    : 'تحديد كمباع')),
                            const PopupMenuItem(
                                value: 'del', child: Text('حذف')),
                          ],
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
          const SizedBox(height: 16),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: OutlinedButton.icon(
              onPressed: () async {
                await sb.auth.signOut();
                Repo.clearCache();
              },
              icon: const Icon(Icons.logout),
              label: const Text('تسجيل الخروج'),
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../repo.dart';

class AddListingScreen extends StatefulWidget {
  const AddListingScreen({super.key});
  @override
  State<AddListingScreen> createState() => _AddListingScreenState();
}

class _AddListingScreenState extends State<AddListingScreen> {
  final _form = GlobalKey<FormState>();
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _price = TextEditingController();
  final _phone = TextEditingController();
  int? _cat;
  int? _city;
  String _condition = 'used';
  final List<Pic> _pics = [];
  bool _busy = false;
  String _sellerName = '';

  @override
  void initState() {
    super.initState();
    Repo.profile().then((p) {
      if (!mounted || p == null) return;
      setState(() {
        _sellerName = (p['full_name'] ?? '') as String;
        if (_phone.text.isEmpty) _phone.text = (p['phone'] ?? '') as String;
        _city ??= p['city_id'] as int?;
      });
    });
  }

  @override
  void dispose() {
    _title.dispose();
    _desc.dispose();
    _price.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final left = 8 - _pics.length;
    if (left <= 0) return;
    final files = await ImagePicker()
        .pickMultiImage(imageQuality: 80, maxWidth: 1600, limit: left > 1 ? left : null);
    for (final f in files.take(left)) {
      final name = f.name.toLowerCase();
      final ext = name.endsWith('.png')
          ? 'png'
          : name.endsWith('.webp')
              ? 'webp'
              : 'jpg';
      _pics.add(Pic(await f.readAsBytes(), ext));
    }
    if (mounted) setState(() {});
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    if (_pics.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('أضف صورة واحدة على الأقل')));
      return;
    }
    setState(() => _busy = true);
    try {
      final urls = await Repo.uploadImages(_pics);
      final priceText = _price.text.trim().replaceAll(',', '');
      await Repo.createListing({
        'user_id': Repo.uid,
        'title': _title.text.trim(),
        'description': _desc.text.trim(),
        'price': priceText.isEmpty ? null : double.parse(priceText),
        'category_id': _cat,
        'city_id': _city,
        'condition': _condition,
        'images': urls,
        'seller_name': _sellerName,
        'contact_phone': _phone.text.trim(),
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تم نشر الإعلان بنجاح')));
      Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(arabicError(e))));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إعلان جديد')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SizedBox(
              height: 96,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  InkWell(
                    onTap: _pick,
                    child: Container(
                      width: 96,
                      decoration: BoxDecoration(
                        border: Border.all(color: Colors.grey),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.add_a_photo_outlined),
                          Text('${_pics.length}/8',
                              style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                  for (var i = 0; i < _pics.length; i++)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(start: 8),
                      child: Stack(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.memory(_pics[i].bytes,
                                width: 96, height: 96, fit: BoxFit.cover),
                          ),
                          Positioned(
                            top: 0,
                            left: 0,
                            child: InkWell(
                              onTap: () => setState(() => _pics.removeAt(i)),
                              child: const CircleAvatar(
                                  radius: 11,
                                  backgroundColor: Colors.black54,
                                  child: Icon(Icons.close,
                                      size: 14, color: Colors.white)),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _title,
              maxLength: 120,
              decoration: const InputDecoration(
                  labelText: 'عنوان الإعلان', border: OutlineInputBorder()),
              validator: (v) =>
                  (v == null || v.trim().length < 3) ? 'اكتب عنواناً (3 أحرف على الأقل)' : null,
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<int>(
              value: _cat,
              decoration: const InputDecoration(
                  labelText: 'التصنيف', border: OutlineInputBorder()),
              items: [
                for (final c in Repo.categories)
                  DropdownMenuItem(value: c.id, child: Text(c.name)),
              ],
              onChanged: (v) => setState(() => _cat = v),
              validator: (v) => v == null ? 'اختر التصنيف' : null,
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<int>(
              value: _city,
              decoration: const InputDecoration(
                  labelText: 'المدينة', border: OutlineInputBorder()),
              items: [
                for (final c in Repo.cities)
                  DropdownMenuItem(value: c.id, child: Text(c.name)),
              ],
              onChanged: (v) => setState(() => _city = v),
              validator: (v) => v == null ? 'اختر المدينة' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _price,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                  labelText: 'السعر بالدينار الليبي (اتركه فارغاً للتفاوض)',
                  border: OutlineInputBorder()),
              validator: (v) {
                final t = (v ?? '').trim().replaceAll(',', '');
                if (t.isEmpty) return null;
                final n = double.tryParse(t);
                return (n == null || n < 0) ? 'سعر غير صحيح' : null;
              },
            ),
            const SizedBox(height: 12),
            SegmentedButton<String>(
              segments: const [
                ButtonSegment(value: 'new', label: Text('جديد')),
                ButtonSegment(value: 'used', label: Text('مستعمل')),
              ],
              selected: {_condition},
              onSelectionChanged: (s) => setState(() => _condition = s.first),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _desc,
              maxLines: 5,
              maxLength: 4000,
              decoration: const InputDecoration(
                  labelText: 'الوصف', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                  labelText: 'رقم التواصل', border: OutlineInputBorder()),
              validator: (v) => (v == null || v.trim().length < 6)
                  ? 'اكتب رقم هاتف صحيحاً'
                  : null,
            ),
            const SizedBox(height: 20),
            SizedBox(
              height: 50,
              child: FilledButton(
                onPressed: _busy ? null : _submit,
                child: _busy
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Text('نشر الإعلان'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

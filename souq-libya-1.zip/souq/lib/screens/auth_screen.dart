import 'package:flutter/material.dart';
import '../repo.dart';

class AuthScreen extends StatefulWidget {
  final bool embedded;
  const AuthScreen({super.key, this.embedded = false});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _form = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  bool _signup = false;
  bool _busy = false;
  bool _hide = true;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    _name.dispose();
    _phone.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      if (_signup) {
        final res = await sb.auth.signUp(
          email: _email.text.trim(),
          password: _pass.text,
          data: {'full_name': _name.text.trim(), 'phone': _phone.text.trim()},
        );
        if (res.session == null) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
              content: Text('تم إنشاء الحساب. افتح رسالة التأكيد في بريدك ثم سجّل الدخول')));
          setState(() => _signup = false);
          return;
        }
      } else {
        await sb.auth.signInWithPassword(
            email: _email.text.trim(), password: _pass.text);
      }
      Repo.clearCache();
      if (mounted && Navigator.canPop(context)) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(arabicError(e))));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _reset() async {
    final email = _email.text.trim();
    if (!email.contains('@')) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('اكتب بريدك الإلكتروني أولاً')));
      return;
    }
    try {
      await sb.auth.resetPasswordForEmail(email);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('تم إرسال رابط استعادة كلمة المرور')));
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(arabicError(e))));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: widget.embedded
          ? null
          : AppBar(title: Text(_signup ? 'إنشاء حساب' : 'تسجيل الدخول')),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _form,
            child: Column(
              children: [
                const Icon(Icons.storefront, size: 72, color: Color(0xFF1B7F4B)),
                const SizedBox(height: 8),
                const Text('سوق ليبيا',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                const SizedBox(height: 20),
                if (_signup) ...[
                  TextFormField(
                    controller: _name,
                    decoration: const InputDecoration(
                        labelText: 'الاسم', border: OutlineInputBorder()),
                    validator: (v) =>
                        (v == null || v.trim().length < 2) ? 'اكتب اسمك' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: _phone,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(
                        labelText: 'رقم الهاتف', border: OutlineInputBorder()),
                    validator: (v) => (v == null || v.trim().length < 9)
                        ? 'رقم هاتف غير صحيح'
                        : null,
                  ),
                  const SizedBox(height: 12),
                ],
                TextFormField(
                  controller: _email,
                  keyboardType: TextInputType.emailAddress,
                  textDirection: TextDirection.ltr,
                  decoration: const InputDecoration(
                      labelText: 'البريد الإلكتروني',
                      border: OutlineInputBorder()),
                  validator: (v) => (v == null || !v.contains('@'))
                      ? 'بريد إلكتروني غير صحيح'
                      : null,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _pass,
                  obscureText: _hide,
                  textDirection: TextDirection.ltr,
                  decoration: InputDecoration(
                    labelText: 'كلمة المرور',
                    border: const OutlineInputBorder(),
                    suffixIcon: IconButton(
                      icon: Icon(_hide ? Icons.visibility : Icons.visibility_off),
                      onPressed: () => setState(() => _hide = !_hide),
                    ),
                  ),
                  validator: (v) => (v == null || v.length < 6)
                      ? '6 أحرف على الأقل'
                      : null,
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: FilledButton(
                    onPressed: _busy ? null : _submit,
                    child: _busy
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(strokeWidth: 2))
                        : Text(_signup ? 'إنشاء الحساب' : 'دخول'),
                  ),
                ),
                TextButton(
                  onPressed: () => setState(() => _signup = !_signup),
                  child: Text(_signup
                      ? 'لديك حساب؟ سجّل الدخول'
                      : 'ليس لديك حساب؟ أنشئ حساباً'),
                ),
                if (!_signup)
                  TextButton(
                      onPressed: _reset, child: const Text('نسيت كلمة المرور؟')),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

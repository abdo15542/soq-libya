import 'package:flutter/material.dart';
import '../models.dart';
import '../repo.dart';
import 'auth_screen.dart';
import 'widgets.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المفضلة')),
      body: AuthGuard(
        loggedOut: (_) => const AuthScreen(embedded: true),
        builder: (_) => const _FavList(),
      ),
    );
  }
}

class _FavList extends StatefulWidget {
  const _FavList();
  @override
  State<_FavList> createState() => _FavListState();
}

class _FavListState extends State<_FavList> {
  late Future<List<Listing>> _f = Repo.favorites();

  void _reload() => setState(() => _f = Repo.favorites());

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Listing>>(
      future: _f,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snap.hasError) return Center(child: Text(arabicError(snap.error!)));
        final items = snap.data!;
        if (items.isEmpty) {
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView(children: const [
              SizedBox(height: 120),
              Center(child: Text('لم تضف أي إعلان إلى المفضلة بعد')),
            ]),
          );
        }
        return RefreshIndicator(
          onRefresh: () async => _reload(),
          child: ListingsGrid(items: items, onChanged: _reload),
        );
      },
    );
  }
}

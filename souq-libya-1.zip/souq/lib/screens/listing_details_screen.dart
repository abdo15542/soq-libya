import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models.dart';
import '../repo.dart';
import '../utils.dart';
import 'auth_screen.dart';

class ListingDetailsScreen extends StatefulWidget {
  final Listing listing;
  const ListingDetailsScreen({super.key, required this.listing});
  @override
  State<ListingDetailsScreen> createState() => _ListingDetailsScreenState();
}

class _ListingDetailsScreenState extends State<ListingDetailsScreen> {
  bool _fav = false;
  bool _admin = false;
  bool _changed = false;
  int _page = 0;

  Listing get l => widget.listing;
  bool get _owner => Repo.uid == l.userId;

  @override
  void initState() {
    super.initState();
    Repo.isFavorite(l.id).then((v) {
      if (mounted) setState(() => _fav = v);
    });
    Repo.isAdmin().then((v) {
      if (mounted) setState(() => _admin = v);
    });
  }

  void _snack(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));

  Future<bool> _requireLogin() async {
    if (sb.auth.currentUser != null) return true;
    final ok = await Navigator.push<bool>(
        context, MaterialPageRoute(builder: (_) => const AuthScreen()));
    return ok == true;
  }

  Future<void> _toggleFav() async {
    if (!await _requireLogin()) return;
    try {
      await Repo.setFavorite(l.id, !_fav);
      if (mounted) setState(() => _fav = !_fav);
      _changed = true;
    } catch (e) {
      _snack(arabicError(e));
    }
  }

  Future<void> _call() async {
    final ok = await launchUrl(Uri.parse('tel:${l.contactPhone}'));
    if (!ok) _snack('تعذّر فتح تطبيق الاتصال');
  }

  Future<void> _whatsapp() async {
    final msg = Uri.encodeComponent('مرحباً، بخصوص إعلانك "${l.title}" في سوق ليبيا');
    final ok = await launchUrl(
      Uri.parse('https://wa.me/${intlPhone(l.contactPhone)}?text=$msg'),
      mode: LaunchMode.externalApplication,
    );
    if (!ok) _snack('تعذّر فتح واتساب');
  }

  Future<void> _report() async {
    if (!await _requireLogin()) return;
    final c = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('الإبلاغ عن الإعلان'),
        content: TextField(
          controller: c,
          maxLines: 3,
          decoration: const InputDecoration(
              hintText: 'اذكر السبب (احتيال، محتوى مخالف...)'),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(context, c.text.trim()),
              child: const Text('إرسال')),
        ],
      ),
    );
    if (reason == null || reason.length < 3) return;
    try {
      await Repo.report(l.id, reason);
      _snack('تم إرسال البلاغ، شكراً لك');
    } catch (e) {
      _snack(arabicError(e));
    }
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('حذف الإعلان'),
        content: const Text('هل أنت متأكد؟'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('حذف')),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await Repo.deleteListing(l);
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      _snack(arabicError(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) Navigator.pop(context, _changed);
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('تفاصيل الإعلان'),
          actions: [
            IconButton(
              icon: Icon(_fav ? Icons.favorite : Icons.favorite_border,
                  color: _fav ? Colors.red : null),
              onPressed: _toggleFav,
            ),
            PopupMenuButton<String>(
              onSelected: (v) => v == 'report' ? _report() : _delete(),
              itemBuilder: (_) => [
                if (!_owner)
                  const PopupMenuItem(value: 'report', child: Text('إبلاغ')),
                if (_owner || _admin)
                  const PopupMenuItem(value: 'del', child: Text('حذف الإعلان')),
              ],
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.only(bottom: 24),
          children: [
            if (l.images.isEmpty)
              Container(
                height: 220,
                color: Colors.grey.shade200,
                child: const Icon(Icons.image_outlined, size: 64, color: Colors.grey),
              )
            else
              SizedBox(
                height: 300,
                child: Stack(
                  children: [
                    PageView.builder(
                      itemCount: l.images.length,
                      onPageChanged: (i) => setState(() => _page = i),
                      itemBuilder: (_, i) => GestureDetector(
                        onTap: () => showDialog(
                          context: context,
                          builder: (_) => Dialog.fullscreen(
                            backgroundColor: Colors.black,
                            child: Stack(children: [
                              Center(
                                child: InteractiveViewer(
                                    child: Image.network(l.images[i])),
                              ),
                              Positioned(
                                top: 36,
                                right: 12,
                                child: IconButton(
                                  color: Colors.white,
                                  icon: const Icon(Icons.close),
                                  onPressed: () => Navigator.pop(context),
                                ),
                              ),
                            ]),
                          ),
                        ),
                        child: Image.network(l.images[i],
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) =>
                                const Center(child: Icon(Icons.broken_image))),
                      ),
                    ),
                    if (l.images.length > 1)
                      Positioned(
                        bottom: 8,
                        left: 0,
                        right: 0,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            for (var i = 0; i < l.images.length; i++)
                              Container(
                                width: 8,
                                height: 8,
                                margin: const EdgeInsets.symmetric(horizontal: 3),
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: i == _page ? Colors.white : Colors.white54,
                                ),
                              ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (l.status == 'sold')
                    Container(
                      margin: const EdgeInsets.only(bottom: 8),
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      color: Colors.red,
                      child: const Text('تم البيع',
                          style: TextStyle(color: Colors.white)),
                    ),
                  Text(l.title,
                      style: const TextStyle(
                          fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(formatPrice(l.price),
                      style: const TextStyle(
                          fontSize: 22,
                          color: Color(0xFF1B7F4B),
                          fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      Chip(
                          avatar: const Icon(Icons.location_on, size: 18),
                          label: Text(Repo.cityName(l.cityId))),
                      Chip(
                          avatar: const Icon(Icons.category, size: 18),
                          label: Text(Repo.categoryName(l.categoryId))),
                      Chip(label: Text(l.condition == 'new' ? 'جديد' : 'مستعمل')),
                      Chip(
                          avatar: const Icon(Icons.access_time, size: 18),
                          label: Text(timeAgo(l.createdAt))),
                    ],
                  ),
                  const Divider(height: 28),
                  const Text('الوصف',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(l.description.isEmpty ? 'لا يوجد وصف' : l.description,
                      style: const TextStyle(fontSize: 15, height: 1.5)),
                  const Divider(height: 28),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const CircleAvatar(child: Icon(Icons.person)),
                    title: Text(l.sellerName.isEmpty ? 'البائع' : l.sellerName),
                    subtitle: const Text('الناشر'),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          onPressed: _call,
                          icon: const Icon(Icons.call),
                          label: const Text('اتصال'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: FilledButton.icon(
                          style: FilledButton.styleFrom(
                              backgroundColor: const Color(0xFF25D366)),
                          onPressed: _whatsapp,
                          icon: const Icon(Icons.chat),
                          label: const Text('واتساب'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'نصيحة أمان: عاين السلعة بنفسك ولا تحوّل أي مبلغ قبل الاستلام.',
                    style: TextStyle(color: Colors.grey, fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models.dart';
import '../repo.dart';
import '../utils.dart';
import 'listing_details_screen.dart';

/// يعرض المحتوى فقط إذا كان المستخدم مسجّلاً، ويتحدّث تلقائياً عند الدخول/الخروج
class AuthGuard extends StatelessWidget {
  final Widget Function(BuildContext) builder;
  final Widget Function(BuildContext) loggedOut;
  const AuthGuard({super.key, required this.builder, required this.loggedOut});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<AuthState>(
      stream: sb.auth.onAuthStateChange,
      builder: (context, _) => sb.auth.currentUser == null
          ? loggedOut(context)
          : builder(context),
    );
  }
}

class ListingCard extends StatelessWidget {
  final Listing listing;
  final VoidCallback? onChanged;
  const ListingCard({super.key, required this.listing, this.onChanged});

  @override
  Widget build(BuildContext context) {
    final l = listing;
    return Card(
      clipBehavior: Clip.antiAlias,
      elevation: 1,
      child: InkWell(
        onTap: () async {
          final changed = await Navigator.push<bool>(
            context,
            MaterialPageRoute(builder: (_) => ListingDetailsScreen(listing: l)),
          );
          if (changed == true) onChanged?.call();
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  l.images.isEmpty
                      ? Container(
                          color: Colors.grey.shade200,
                          child: const Icon(Icons.image_outlined,
                              size: 40, color: Colors.grey))
                      : Image.network(l.images.first,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                              color: Colors.grey.shade200,
                              child: const Icon(Icons.broken_image,
                                  color: Colors.grey))),
                  if (l.status == 'sold')
                    Positioned(
                      top: 8,
                      right: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        color: Colors.red,
                        child: const Text('تم البيع',
                            style: TextStyle(color: Colors.white, fontSize: 12)),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(l.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 2),
                  Text(formatPrice(l.price),
                      style: const TextStyle(
                          color: Color(0xFF1B7F4B), fontWeight: FontWeight.bold)),
                  const SizedBox(height: 2),
                  Text('${Repo.cityName(l.cityId)} · ${timeAgo(l.createdAt)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: Colors.grey)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ListingsGrid extends StatelessWidget {
  final List<Listing> items;
  final VoidCallback onChanged;
  final ScrollController? controller;
  const ListingsGrid(
      {super.key, required this.items, required this.onChanged, this.controller});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      controller: controller,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 90),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 0.78,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemCount: items.length,
      itemBuilder: (_, i) =>
          ListingCard(listing: items[i], onChanged: onChanged),
    );
  }
}

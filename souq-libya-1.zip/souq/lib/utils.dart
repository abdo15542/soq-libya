String formatPrice(double? p) {
  if (p == null) return 'السعر عند الاتصال';
  final s = p.toStringAsFixed(p == p.roundToDouble() ? 0 : 2);
  final parts = s.split('.');
  final intPart = parts[0].replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return '$intPart${parts.length > 1 ? '.${parts[1]}' : ''} د.ل';
}

String timeAgo(DateTime d) {
  final diff = DateTime.now().difference(d);
  if (diff.inMinutes < 1) return 'الآن';
  if (diff.inMinutes < 60) return 'منذ ${diff.inMinutes} دقيقة';
  if (diff.inHours < 24) return 'منذ ${diff.inHours} ساعة';
  if (diff.inDays < 30) return 'منذ ${diff.inDays} يوم';
  return '${d.year}/${d.month}/${d.day}';
}

/// يحوّل رقم ليبي إلى الصيغة الدولية بدون + (للواتساب)
String intlPhone(String raw) {
  var d = raw.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('00')) d = d.substring(2);
  if (d.startsWith('218')) return d;
  if (d.startsWith('0')) return '218${d.substring(1)}';
  return '218$d';
}
